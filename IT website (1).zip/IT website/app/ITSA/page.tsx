'use client';

import Link from 'next/link';
import { Code, Users, Activity, Star, Mail } from 'lucide-react';

const activities = [
    {
        title: 'Hackathons',
        icon: <Code className="w-6 h-6 text-blue-600" />,
        description: 'Competitive coding events to boost real-world problem-solving skills.',
    },
    {
        title: 'Workshops',
        icon: <Activity className="w-6 h-6 text-blue-600" />,
        description: 'Hands-on sessions on trending technologies by industry experts.',
    },
    {
        title: 'Tech Talks',
        icon: <Users className="w-6 h-6 text-blue-600" />,
        description: 'Interactive sessions with alumni, developers, and entrepreneurs.',
    },
    {
        title: 'Fun Events',
        icon: <Star className="w-6 h-6 text-blue-600" />,
        description: 'Gaming nights, quizzes, and cultural events to balance work and play.',
    },
];

const team = [
    { name: 'DemoName', role: 'President' },
    { name: 'DemoName ', role: 'Vice President' },
    { name: 'DemoName ', role: 'Treasurer' },
    { name: 'DemoName ', role: 'Secretary' },
];

export default function ITSAPage() {
    return (
        <div className="min-h-screen bg-white pt-24 px-4 sm:px-10 text-gray-800">
            {/* Hero */}
            <section className="text-center mb-16">
                <h1 className="text-4xl sm:text-5xl font-extrabold text-blue-700">ITSA - Information Technology Students’ Association</h1>
                <p className="mt-4 text-lg max-w-3xl mx-auto text-gray-600">
                    A platform by students, for students – cultivating leadership, innovation, and growth in the world of technology.
                </p>
            </section>

            {/* About */}
            <section className="mb-16 max-w-4xl mx-auto text-center">
                <h2 className="text-2xl font-bold mb-4 text-gray-800">What is ITSA?</h2>
                <p className="text-gray-600 text-md leading-relaxed">
                    ITSA is a student-led body in the Department of Information Technology. Our mission is to promote
                    technical excellence, teamwork, and creativity by organizing a variety of academic and cultural activities.
                    From technical workshops to fun fests, ITSA is the heartbeat of our department’s student life.
                </p>
            </section>

            {/* Activities */}
            <section className="mb-20">
                <h2 className="text-2xl font-bold text-center mb-8">What We Do</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
                    {activities.map((activity, idx) => (
                        <div key={idx} className="p-5 border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition">
                            <div className="flex items-center gap-3 mb-2">
                                {activity.icon}
                                <h3 className="text-lg font-semibold">{activity.title}</h3>
                            </div>
                            <p className="text-gray-600 text-sm">{activity.description}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Team */}
            <section className="mb-20">
                <h2 className="text-2xl font-bold text-center mb-8">Core Team</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-4xl mx-auto text-center">
                    {team.map((member, idx) => (
                        <div key={idx} className="bg-gray-100 p-4 rounded-lg shadow-sm hover:shadow-md transition">
                            <h4 className="font-semibold text-md text-gray-800">{member.name}</h4>
                            <p className="text-sm text-blue-600">{member.role}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Join CTA */}
            <section className="text-center pb-20">
                <p className="text-lg font-medium text-gray-700">Interested in being a part of ITSA?</p>
                <Link
                    href="/contact"
                    className="inline-flex items-center gap-2 mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition"
                >
                    <Mail className="w-4 h-4" />
                    Contact Us
                </Link>
            </section>
        </div>
    );
}
