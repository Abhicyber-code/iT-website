export default function AlumniPage() {
    return (
        <div className="bg-white text-gray-800">

            {/* Hero Section */}
            <section className="relative bg-gradient-to-r from-blue-800 to-blue-600 text-white py-20 px-6 text-center">
                <div className="max-w-5xl mx-auto">
                    <h1 className="text-5xl font-extrabold mb-4">Our Proud Alumni</h1>
                    <p className="text-lg opacity-90">
                        Bridging the past with the future — IT graduates shaping the world.
                    </p>
                </div>
            </section>

            {/* Success Highlights */}
            <section className="py-16 px-6 bg-gray-50">
                <div className="max-w-6xl mx-auto">
                    <h2 className="text-3xl font-semibold text-center mb-12 text-blue-800">Global Impact</h2>
                    <div className="grid md:grid-cols-3 gap-10">
                        {[
                            {
                                name: 'Amit Rane',
                                image: 'https://randomuser.me/api/portraits/men/75.jpg',
                                position: 'Senior Software Engineer, Google (USA)',
                            },
                            {
                                name: 'Neha Patil',
                                image: 'https://randomuser.me/api/portraits/women/65.jpg',
                                position: 'Data Scientist, Amazon (Germany)',
                            },
                            {
                                name: 'Rahul Jadhav',
                                image: 'https://randomuser.me/api/portraits/men/52.jpg',
                                position: 'Founder, CodeCraft Tech (Pune)',
                            },
                        ].map((alum, index) => (
                            <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transition">
                                <img
                                    src={alum.image}
                                    alt={alum.name}
                                    className="w-28 h-28 object-cover rounded-full mx-auto mb-4"
                                />
                                <h3 className="text-xl font-semibold text-center">{alum.name}</h3>
                                <p className="text-sm text-gray-600 text-center">{alum.position}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Testimonial Section */}
            <section className="bg-white py-20 px-6 border-t border-gray-200">
                <div className="max-w-5xl mx-auto">
                    <h2 className="text-3xl font-semibold text-center mb-12 text-blue-800">Voices from the World</h2>
                    <div className="grid md:grid-cols-2 gap-8">
                        {[
                            {
                                name: 'Pooja Sharma',
                                quote:
                                    'The foundation laid at JSCOE’s IT department helped me crack my MS at Stanford and land my dream job in Silicon Valley!',
                            },
                            {
                                name: 'Saurabh Deshmukh',
                                quote:
                                    'Thanks to the industry-oriented teaching, I was confident walking into interviews. I owe my success at Deloitte to my time here.',
                            },
                        ].map((testimonial, index) => (
                            <div key={index} className="bg-gray-100 p-6 rounded-lg shadow-sm">
                                <p className="italic text-gray-700 mb-4">“{testimonial.quote}”</p>
                                <p className="text-sm font-semibold text-blue-800">– {testimonial.name}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* World Map / Reach */}
            <section className="py-20 bg-blue-50">
                <div className="max-w-6xl mx-auto px-6">
                    <h2 className="text-3xl font-semibold text-center mb-8 text-blue-800">Alumni Across the Globe</h2>
                    <div className="flex justify-center">
                        <img
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRE80CtVYCNeSsJMH5ca9rQ0Qj_GeHcrdI6xA&s"
                            alt="World Map"
                            className="w-full max-w-4xl rounded-lg shadow-lg"
                        />
                    </div>
                </div>
            </section>
        </div>
    );
}
