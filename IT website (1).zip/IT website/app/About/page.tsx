// import React from 'react';

// export default function AboutITDepartment() {
//     return (
//         <div className="bg-gray-50 text-gray-800 pt-20 pb-10 px-6 md:px-20 font-sans">

//             {/* Page Title */}
//             <h1 className="text-4xl md:text-5xl font-bold text-center text-blue-900 mb-12">
//                 Department of Information Technology – JSCOE
//             </h1>

//             {/* HoD Message */}
//             <section className="bg-white shadow-xl rounded-xl p-8 md:p-12 mb-16 flex flex-col lg:flex-row items-center gap-10">
//                 <img
//                     src="https://jspmjscoe.edu.in/storage/Departments/SRRangari.jpg"
//                     alt="HoD"
//                     className="w-48 h-64 object-cover rounded-lg shadow-md border"
//                 />
//                 <div>
//                     <h2 className="text-2xl font-semibold text-blue-800 mb-4">HoD’s Message</h2>
//                     <p className="text-justify mb-4">
//                         Welcome to the Department of Information Technology at JSPM’s Jayawantrao Sawant College of Engineering, Hadapsar Pune. Our Vision is to develop competent IT professionals for e-development of emerging societal needs.
//                     </p>
//                     <p className="text-justify mb-4">
//                         The department offers B.E. degree program in Information Technology affiliated to Savitribai Phule Pune University and accredited by National Board of Accreditation. The department has a team of well qualified, experienced and motivated faculty members to prepare the young minds of our students towards industry-required skills, both technical & interpersonal.
//                     </p>
//                     <p className="text-justify mb-4">
//                         Students actively participate in training and development programs and graduate with hands-on experience on current technologies. The department has an excellent placement record with alumni working across the globe in top tech firms.
//                     </p>
//                     <p className="text-justify">
//                         We regularly organize professional development activities through ITSA and Innovation Club to build leadership, communication, time management, and problem-solving skills. Our mission is to shape careers, enrich minds, and nurture socially responsible professionals.
//                     </p>
//                     <p className="mt-6 font-semibold">– Prof. Sudhir Rangari, Head of Department</p>
//                 </div>
//             </section>

//             {/* About Department */}
//             <section className="bg-white shadow-xl rounded-xl p-8 md:p-12 mb-16">
//                 <h2 className="text-2xl font-semibold text-blue-800 mb-6">About Information Technology</h2>
//                 <p className="text-justify mb-4">
//                     Information Technology has deeply impacted modern life. With ongoing advances in hardware, software, and networking, costs are reduced and efficiency improved, influencing society both socially and economically.
//                 </p>
//                 <p className="text-justify mb-4">
//                     India’s IT sector is a global leader, producing world-class professionals. At JSCOE, we deliver effective, ICT-enabled learning with advanced labs and industry-focused curriculum. Our graduates excel in designing and developing multidisciplinary solutions.
//                 </p>
//                 <p className="text-justify mb-4">
//                     Major modules taught include Software Development, OS, Architecture, Web Tech, Networks, Databases, as well as emerging fields like Data Science, ML, and IoT.
//                 </p>
//                 <p className="text-justify mb-4">
//                     Our Entrepreneur Development Cell has produced over 20 alumni entrepreneurs with an annual turnover of ₹45 Lacs collectively. Over 40 students have completed their MS abroad and hold leading roles globally.
//                 </p>
//                 <p className="text-justify">
//                     Our consistent vision has led to top-tier placements, often surpassing other departments. We strive to continually produce industry-ready, globally competent IT professionals.
//                 </p>
//             </section>

//             {/* Group Photo */}
//             <section className="mb-10 flex justify-center">
//                 <div className="w-full max-w-4xl px-4">
//                     <h2 className="text-2xl font-semibold text-blue-800 text-center mb-6">
//                         Proud Alumni – Passed Out Batch
//                     </h2>
//                     <img
//                         src="https://jspmjscoe.edu.in/storage/Departments/ITDepartment.jpg"
//                         alt="Group of Passed Out Students"
//                         className="rounded-lg shadow-lg object-cover w-full"
//                     />
//                 </div>
//             </section>

//         </div>
//     );
// }


import React from 'react';

export default function AboutITDepartment() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-100 to-white text-gray-800 pt-24 pb-16 px-6 md:px-20 font-[system-ui,sans-serif]">

            {/* Page Title */}
            <h1 className="text-4xl md:text-5xl font-semibold text-center text-gray-900 tracking-tight mb-16">
                Department of Information Technology <br className="hidden md:block" />
                <span className="text-blue-600">JSCOE</span>
            </h1>

            {/* HoD Message */}
            <section className="backdrop-blur-md bg-white/80 border border-gray-200 shadow-md rounded-3xl p-8 md:p-12 mb-20 flex flex-col lg:flex-row items-center gap-10 transition-all duration-500 hover:shadow-xl">
                <img
                    src="https://jspmjscoe.edu.in/storage/Departments/SRRangari.jpg"
                    alt="HoD"
                    className="w-52 h-72 object-cover rounded-2xl shadow-lg border border-gray-200"
                />
                <div>
                    <h2 className="text-3xl font-medium text-gray-900 mb-6">HoD’s Message</h2>
                    <div className="space-y-4 text-[17px] leading-relaxed text-gray-700">
                        <p>
                            Welcome to the Department of Information Technology at JSPM’s Jayawantrao Sawant College of Engineering, Hadapsar Pune. Our Vision is to develop competent IT professionals for e-development of emerging societal needs.
                        </p>
                        <p>
                            The department offers a B.E. degree program in Information Technology affiliated to Savitribai Phule Pune University and accredited by the National Board of Accreditation.
                        </p>
                        <p>
                            Students actively participate in training and development programs and graduate with hands-on experience on current technologies. The department has an excellent placement record with alumni working across the globe in top tech firms.
                        </p>
                        <p>
                            We regularly organize professional development activities through ITSA and Innovation Club to build leadership, communication, time management, and problem-solving skills.
                        </p>
                    </div>
                    <p className="mt-8 font-medium text-gray-800 text-right">– Prof. Sudhir Rangari, Head of Department</p>
                </div>
            </section>

            {/* About Department */}
            <section className="backdrop-blur-md bg-white/80 border border-gray-200 shadow-md rounded-3xl p-8 md:p-12 mb-20 transition-all duration-500 hover:shadow-xl">
                <h2 className="text-3xl font-medium text-gray-900 mb-8">About Information Technology</h2>
                <div className="space-y-4 text-[17px] leading-relaxed text-gray-700">
                    <p>
                        Information Technology has deeply impacted modern life. With ongoing advances in hardware, software, and networking, costs are reduced and efficiency improved, influencing society both socially and economically.
                    </p>
                    <p>
                        India’s IT sector is a global leader, producing world-class professionals. At JSCOE, we deliver effective, ICT-enabled learning with advanced labs and industry-focused curriculum.
                    </p>
                    <p>
                        Major modules taught include Software Development, OS, Architecture, Web Tech, Networks, Databases, as well as emerging fields like Data Science, ML, and IoT.
                    </p>
                    <p>
                        Our Entrepreneur Development Cell has produced over 20 alumni entrepreneurs with an annual turnover of ₹45 Lacs collectively. Over 40 students have completed their MS abroad and hold leading roles globally.
                    </p>
                    <p>
                        Our consistent vision has led to top-tier placements, often surpassing other departments. We strive to continually produce industry-ready, globally competent IT professionals.
                    </p>
                </div>
            </section>

            {/* Group Photo */}
            <section className="mb-10 flex justify-center">
                <div className="w-full max-w-4xl px-4 text-center">
                    <h2 className="text-3xl font-medium text-gray-900 mb-6">
                        Proud Alumni – Passed Out Batch
                    </h2>
                    <img
                        src="https://jspmjscoe.edu.in/storage/Departments/ITDepartment.jpg"
                        alt="Group of Passed Out Students"
                        className="rounded-3xl shadow-xl object-cover w-full transition-all duration-500 hover:scale-[1.01]"
                    />
                </div>
            </section>

        </div>
    );
}
