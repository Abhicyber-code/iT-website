// 'use client';

// import { useState } from 'react';
// import { CheckCircle, XCircle } from 'lucide-react';

// const studentsList = [
//     'Aarav Patil', 'Sneha Deshmukh', 'Rohan Jadhav', 'Pooja Shinde', 'Omkar Pawar',
//     'Prachi Kale', 'Tanmay More', 'Rutuja Chavan', 'Sahil Gaikwad', 'Shruti Joshi',
//     'Kunal Salunkhe', 'Isha Kadam', 'Pratik Naik', 'Neha Bhosale', 'Aniket Lokhande',
//     'Vaishnavi Phadke', 'Aditya Gite', 'Manasi Thakur', 'Sanket Raut', 'Komal Wagh',
//     'Nikhil Khot', 'Sayali Shingade', 'Tushar Zende', 'Megha Wavhal', 'Jay Pingle',
//     'Asmita Gawade', 'Saurabh Bhujbal', 'Diksha Bane', 'Shubham Rane', 'Ketaki Khare',
// ].map((name, index) => ({ id: index + 1, name }));

// export default function AttendancePage() {
//     const [attendance, setAttendance] = useState({});
//     const [visibleCount, setVisibleCount] = useState(10);

//     const toggleAttendance = (id) => {
//         setAttendance((prev) => ({
//             ...prev,
//             [id]: !prev[id],
//         }));
//     };

//     const handleSubmit = () => {
//         alert('✅ Attendance submitted! Check console for data.');
//         console.log('📝 Attendance Data:', attendance);
//     };

//     const handleSeeMore = () => {
//         setVisibleCount((prev) => prev + 10);
//     };

//     return (
//         <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4 sm:p-8">
//             <div className="max-w-5xl mx-auto bg-white rounded-xl shadow-xl p-4 sm:p-8">
//                 <h1 className="text-2xl sm:text-3xl font-bold text-center text-blue-700 mb-6">
//                     📋 Smart Attendance System
//                 </h1>

//                 <div className="overflow-x-auto rounded-lg">
//                     <table className="min-w-full text-sm sm:text-base border-separate border-spacing-y-3">
//                         <thead>
//                             <tr>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">#</th>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">Student Name</th>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">Status</th>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">Action</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {studentsList.slice(0, visibleCount).map((student, index) => (
//                                 <tr
//                                     key={student.id}
//                                     className="bg-white shadow rounded-xl transition hover:scale-[1.01]"
//                                 >
//                                     <td className="px-4 py-3 text-gray-700 whitespace-nowrap">{index + 1}</td>
//                                     <td className="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
//                                         {student.name}
//                                     </td>
//                                     <td className="px-4 py-3 whitespace-nowrap">
//                                         {attendance[student.id] ? (
//                                             <span className="inline-flex items-center gap-1 text-green-600 font-semibold">
//                                                 <CheckCircle className="w-4 h-4" /> Present
//                                             </span>
//                                         ) : (
//                                             <span className="inline-flex items-center gap-1 text-red-500 font-semibold">
//                                                 <XCircle className="w-4 h-4" /> Absent
//                                             </span>
//                                         )}
//                                     </td>
//                                     <td className="px-4 py-3 whitespace-nowrap">
//                                         <button
//                                             onClick={() => toggleAttendance(student.id)}
//                                             className={`px-3 py-1 sm:px-4 sm:py-2 rounded-full font-semibold text-white transition-all duration-300 text-sm sm:text-base ${attendance[student.id]
//                                                     ? 'bg-red-500 hover:bg-red-600'
//                                                     : 'bg-green-500 hover:bg-green-600'
//                                                 }`}
//                                         >
//                                             Mark {attendance[student.id] ? 'Absent' : 'Present'}
//                                         </button>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 </div>

//                 {visibleCount < studentsList.length && (
//                     <div className="text-center mt-6">
//                         <button
//                             onClick={handleSeeMore}
//                             className="text-blue-600 font-semibold hover:underline"
//                         >
//                             ↓ See more students
//                         </button>
//                     </div>
//                 )}

//                 <div className="text-center mt-10">
//                     <button
//                         onClick={handleSubmit}
//                         className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-base sm:text-lg font-semibold shadow-md transition-all duration-300"
//                     >
//                         ✅ Submit Attendance
//                     </button>
//                 </div>
//             </div>
//         </div>
//     );
// }


'use client';

import { useState } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

const studentsList = [
    'Aarav Patil', 'Sneha Deshmukh', 'Rohan Jadhav', 'Pooja Shinde', 'Omkar Pawar',
    'Prachi Kale', 'Tanmay More', 'Rutuja Chavan', 'Sahil Gaikwad', 'Shruti Joshi',
    'Kunal Salunkhe', 'Isha Kadam', 'Pratik Naik', 'Neha Bhosale', 'Aniket Lokhande',
    'Vaishnavi Phadke', 'Aditya Gite', 'Manasi Thakur', 'Sanket Raut', 'Komal Wagh',
    'Nikhil Khot', 'Sayali Shingade', 'Tushar Zende', 'Megha Wavhal', 'Jay Pingle',
    'Asmita Gawade', 'Saurabh Bhujbal', 'Diksha Bane', 'Shubham Rane', 'Ketaki Khare',
].map((name, index) => ({ id: index + 1, name }));

export default function AttendancePage() {
    const [attendance, setAttendance] = useState({});
    const [visibleCount, setVisibleCount] = useState(10);

    const toggleAttendance = (id) => {
        setAttendance((prev) => ({
            ...prev,
            [id]: !prev[id],
        }));
    };

    const handleSubmit = () => {
        alert('✅ Attendance submitted! Check console for data.');
        console.log('📝 Attendance Data:', attendance);
    };

    const handleSeeMore = () => {
        setVisibleCount((prev) => prev + 10);
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-300 p-4 sm:p-8">
            <div className="max-w-6xl mx-auto bg-white/70 backdrop-blur-xl rounded-3xl shadow-2xl px-6 py-8 sm:p-12 border border-gray-200">
                <h1 className="text-3xl sm:text-4xl font-bold text-center text-blue-800 mb-10 tracking-tight">
                    📋 Smart Attendance System
                </h1>

                <div className="overflow-x-auto rounded-xl">
                    <table className="min-w-full border-separate border-spacing-y-4">
                        <thead>
                            <tr className="text-left text-gray-600 text-sm sm:text-base">
                                <th className="px-4 py-2 font-semibold">#</th>
                                <th className="px-4 py-2 font-semibold">Student Name</th>
                                <th className="px-4 py-2 font-semibold">Status</th>
                                <th className="px-4 py-2 font-semibold">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {studentsList.slice(0, visibleCount).map((student, index) => (
                                <tr
                                    key={student.id}
                                    className="bg-white/60 shadow-md rounded-xl transition transform hover:scale-[1.01] duration-300"
                                >
                                    <td className="px-4 py-3 text-gray-700 font-medium">{index + 1}</td>
                                    <td className="px-4 py-3 text-gray-900 font-semibold">{student.name}</td>
                                    <td className="px-4 py-3">
                                        {attendance[student.id] ? (
                                            <span className="inline-flex items-center gap-1 text-green-600 font-semibold">
                                                <CheckCircle className="w-5 h-5" /> Present
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center gap-1 text-red-500 font-semibold">
                                                <XCircle className="w-5 h-5" /> Absent
                                            </span>
                                        )}
                                    </td>
                                    <td className="px-4 py-3">
                                        <button
                                            onClick={() => toggleAttendance(student.id)}
                                            className={`px-4 py-2 rounded-full text-white font-semibold text-sm transition-all duration-300 ${attendance[student.id]
                                                    ? 'bg-red-500 hover:bg-red-600'
                                                    : 'bg-green-500 hover:bg-green-600'
                                                }`}
                                        >
                                            Mark {attendance[student.id] ? 'Absent' : 'Present'}
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {visibleCount < studentsList.length && (
                    <div className="text-center mt-8">
                        <button
                            onClick={handleSeeMore}
                            className="text-blue-700 font-medium hover:underline tracking-wide"
                        >
                            ↓ See more students
                        </button>
                    </div>
                )}

                <div className="text-center mt-10">
                    <button
                        onClick={handleSubmit}
                        className="w-full sm:w-auto px-8 py-3 bg-blue-700 hover:bg-blue-800 text-white rounded-2xl text-lg font-semibold shadow-md transition duration-300"
                    >
                        ✅ Submit Attendance
                    </button>
                </div>
            </div>
        </div>
    );
}
