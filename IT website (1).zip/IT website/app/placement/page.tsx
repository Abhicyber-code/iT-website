'use client';

import { Briefcase, GraduationCap, FileText, ExternalLink } from 'lucide-react';

const recruiters = ['TCS', 'Infosys', 'Wipro', 'Capgemini', 'L&T', 'Cognizant', 'Tech Mahindra'];
const studentsPlaced = [
    { name: 'Aarav Patil', company: 'TCS', package: '6 LPA' },
    { name: 'Sneha Deshmukh', company: 'Wipro', package: '5 LPA' },
    { name: 'Rohan Jadhav', company: 'Capgemini', package: '5.5 LPA' },
];

const researchPapers = [
    { title: 'AI in Healthcare', author: 'Pooja Shinde', link: '#' },
    { title: 'Blockchain Security', author: 'Omkar Pawar', link: '#' },
    { title: 'IoT-based Smart Campus', author: 'Prachi Kale', link: '#' },
];

const jobLinks = [
    { title: 'Frontend Internship – React', company: 'Internshala', link: 'https://internshala.com/' },
    { title: 'Software Engineer – Fresher Role', company: 'Naukri.com', link: 'https://naukri.com/' },
];

export default function PlacementsPage() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-100 p-6">
            <div className="max-w-6xl mx-auto bg-white rounded-2xl shadow-xl p-6 sm:p-10">
                <h1 className="text-3xl font-bold text-center text-orange-700 mb-8 flex justify-center gap-2">
                    <Briefcase className="w-7 h-7" /> Placements & Research
                </h1>

                {/* Section 1: Placement Stats */}
                <div className="mb-10">
                    <h2 className="text-2xl font-semibold text-gray-800 mb-4">📈 Placement Highlights</h2>
                    <ul className="list-disc list-inside text-gray-700 space-y-2">
                        <li>💼 90% Placement Rate in 2024</li>
                        <li>🎓 Highest Package: <strong>₹12 LPA</strong></li>
                        <li>🏢 Over 30+ Companies Visited</li>
                    </ul>
                </div>

                {/* Section 2: Recruiters */}
                <div className="mb-10">
                    <h2 className="text-2xl font-semibold text-gray-800 mb-4">🏢 Top Recruiters</h2>
                    <div className="flex flex-wrap gap-4">
                        {recruiters.map((company, index) => (
                            <span
                                key={index}
                                className="px-4 py-2 bg-orange-100 text-orange-800 font-medium rounded-full shadow-sm text-sm"
                            >
                                {company}
                            </span>
                        ))}
                    </div>
                </div>

                {/* Section 3: Student Success */}
                <div className="mb-10">
                    <h2 className="text-2xl font-semibold text-gray-800 mb-4">🌟 Student Success Stories</h2>
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {studentsPlaced.map((student, index) => (
                            <div
                                key={index}
                                className="bg-white border rounded-xl shadow p-4 hover:shadow-md transition"
                            >
                                <h3 className="text-lg font-semibold text-orange-700">{student.name}</h3>
                                <p className="text-sm text-gray-600 mt-1">Company: {student.company}</p>
                                <p className="text-sm text-gray-600">Package: {student.package}</p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Section 4: Research */}
                <div className="mb-10">
                    <h2 className="text-2xl font-semibold text-gray-800 mb-4">📚 Research Publications</h2>
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {researchPapers.map((paper, index) => (
                            <div
                                key={index}
                                className="bg-white border rounded-xl shadow p-5 hover:shadow-md transition"
                            >
                                <div className="flex items-center gap-2 mb-2">
                                    <FileText className="text-purple-600 w-5 h-5" />
                                    <h3 className="font-semibold text-gray-800">{paper.title}</h3>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">Author: {paper.author}</p>
                                <a
                                    href={paper.link}
                                    className="inline-flex items-center gap-1 text-sm text-indigo-600 hover:underline"
                                >
                                    View Paper <ExternalLink className="w-4 h-4" />
                                </a>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Section 5: Jobs & Internships */}
                <div>
                    <h2 className="text-2xl font-semibold text-gray-800 mb-4">🧭 Opportunities</h2>
                    <div className="grid gap-6 sm:grid-cols-2">
                        {jobLinks.map((job, index) => (
                            <div
                                key={index}
                                className="bg-white border rounded-xl shadow p-5 hover:shadow-md transition"
                            >
                                <div className="flex items-center gap-2 mb-2">
                                    <GraduationCap className="text-green-600 w-5 h-5" />
                                    <h3 className="font-semibold text-gray-800">{job.title}</h3>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">Company: {job.company}</p>
                                <a
                                    href={job.link}
                                    className="inline-flex items-center gap-1 text-sm text-green-700 hover:underline"
                                >
                                    Apply Now <ExternalLink className="w-4 h-4" />
                                </a>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}
