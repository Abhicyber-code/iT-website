// app/dashboard/page.tsx
export default function Dashboard() {
    return (
        <main className="p-8 mt-16">
            <h1 className="text-3xl font-bold text-blue-900">Dashboard</h1>
            <p className="mt-2 text-gray-700">Welcome to the IT Department Dashboard at JSCOE.</p>
        </main>
    );
}
