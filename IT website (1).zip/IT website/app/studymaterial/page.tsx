

'use client';

import { useState } from 'react';
import { FileText, Download, BookOpen, Youtube, LinkIcon } from 'lucide-react';

const pdfMaterials = [
    { id: 1, title: 'DSA Notes', subject: 'CS', type: 'PDF', link: '#' },
    { id: 2, title: 'DBMS PPT', subject: 'IT', type: 'PPT', link: '#' },
    { id: 3, title: 'Networking Notes', subject: 'CS', type: 'PDF', link: '#' },
];

const videoMaterials = [
    { id: 1, title: 'JavaScript Full Course', channel: 'CodeWithHarry', link: 'https://youtu.be/xyz' },
    { id: 2, title: 'React Crash Course', channel: 'Traversy Media', link: 'https://youtu.be/abc' },
    { id: 3, title: 'DSA in 100 Days', channel: 'Apna College', link: 'https://youtu.be/def' },
    { id: 4, title: 'JavaScript Full Course', channel: 'CodeWithHarry', link: 'https://youtu.be/xyz' },
];

const resourceLinks = [
    { id: 1, title: 'W3Schools HTML', link: 'https://www.w3schools.com/html/' },
    { id: 2, title: 'MDN CSS Docs', link: 'https://developer.mozilla.org/en-US/docs/Web/CSS' },
    { id: 3, title: 'GitHub Student Pack', link: 'https://education.github.com/pack' },
    { id: 4, title: 'W3Schools HTML', link: 'https://www.w3schools.com/html/' },
    { id: 5, title: 'GitHub Student Pack', link: 'https://education.github.com/pack' },
];

export default function StudyMaterialPage() {
    const [search, setSearch] = useState('');

    const filteredPDFs = pdfMaterials.filter((m) =>
        m.title.toLowerCase().includes(search.toLowerCase())
    );
    const filteredVideos = videoMaterials.filter((v) =>
        v.title.toLowerCase().includes(search.toLowerCase())
    );
    const filteredLinks = resourceLinks.filter((r) =>
        r.title.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-100 to-pink-100 p-6 font-sans">
            <div className="max-w-6xl mx-auto backdrop-blur-md bg-white/70 rounded-3xl shadow-2xl p-6 sm:p-10">
                <h1 className="text-4xl font-bold text-center text-indigo-700 mb-8 flex items-center justify-center gap-3 animate-fade-in">
                    <BookOpen className="w-10 h-10 text-purple-600" />
                    Study Material Hub
                </h1>

                <div className="mb-10 flex justify-center animate-fade-in">
                    <input
                        type="text"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder="Search anything..."
                        className="w-full sm:w-96 px-5 py-3 rounded-xl border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white/80 placeholder-gray-700 text-gray-900"
                    />
                </div>


                {/* Section 1: Notes & Slides */}
                <section className="mb-14 animate-fade-in-up">
                    <h2 className="text-2xl font-semibold text-indigo-800 mb-5">📁 Notes & Slides</h2>
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {filteredPDFs.map((item) => (
                            <div key={item.id} className="bg-white/80 border border-indigo-100 rounded-2xl shadow-md p-6 hover:shadow-xl transition-all">
                                <div className="flex items-center gap-2 mb-2">
                                    <FileText className="text-indigo-600 w-5 h-5" />
                                    <h3 className="font-semibold text-gray-800">{item.title}</h3>
                                </div>
                                <p className="text-sm text-gray-600 mb-1">Subject: {item.subject}</p>
                                <p className="text-sm text-gray-600 mb-4">Type: {item.type}</p>
                                <a
                                    href={item.link}
                                    className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm hover:bg-indigo-700 transition"
                                >
                                    <Download className="w-4 h-4" /> Download
                                </a>
                            </div>
                        ))}
                        {filteredPDFs.length === 0 && <p className="text-gray-500">No notes found.</p>}
                    </div>
                </section>

                {/* Section 2: Coding Tutorials */}
                <section className="mb-14 animate-fade-in-up delay-100">
                    <h2 className="text-2xl font-semibold text-red-600 mb-5">🎥 Coding Tutorials</h2>
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {filteredVideos.map((video) => (
                            <div key={video.id} className="bg-white/80 border border-red-100 rounded-2xl shadow-md p-6 hover:shadow-xl transition-all">
                                <div className="flex items-center gap-2 mb-2">
                                    <Youtube className="text-red-500 w-5 h-5" />
                                    <h3 className="font-semibold text-gray-800">{video.title}</h3>
                                </div>
                                <p className="text-sm text-gray-600 mb-4">Channel: {video.channel}</p>
                                <a
                                    href={video.link}
                                    target="_blank"
                                    className="inline-flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-xl text-sm hover:bg-red-600 transition"
                                >
                                    <Youtube className="w-4 h-4" /> Watch
                                </a>
                            </div>
                        ))}
                        {filteredVideos.length === 0 && <p className="text-gray-500">No videos found.</p>}
                    </div>
                </section>

                {/* Section 3: Useful Links */}
                <section className="animate-fade-in-up delay-200">
                    <h2 className="text-2xl font-semibold text-blue-700 mb-5">🔗 Useful Links</h2>
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {filteredLinks.map((link) => (
                            <div key={link.id} className="bg-white/80 border border-blue-100 rounded-2xl shadow-md p-6 hover:shadow-xl transition-all">
                                <div className="flex items-center gap-2 mb-2">
                                    <LinkIcon className="text-blue-500 w-5 h-5" />
                                    <h3 className="font-semibold text-gray-800">{link.title}</h3>
                                </div>
                                <a
                                    href={link.link}
                                    target="_blank"
                                    className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm hover:bg-blue-700 transition"
                                >
                                    Open Link
                                </a>
                            </div>
                        ))}
                        {filteredLinks.length === 0 && <p className="text-gray-500">No links found.</p>}
                    </div>
                </section>
            </div>

            {/* Optional: Add subtle animation styles */}
            <style jsx>{`
        .animate-fade-in {
          animation: fadeIn 1s ease-out;
        }
        .animate-fade-in-up {
          animation: fadeInUp 0.8s ease-out both;
        }
        .delay-100 {
          animation-delay: 0.1s;
        }
        .delay-200 {
          animation-delay: 0.2s;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        @keyframes fadeInUp {
          from {
            transform: translateY(20px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
      `}</style>
        </div>
    );
}
