
'use client';

import { useState } from 'react';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

const facultyData: Record<string, Array<{ time: string, subject: string, faculty: string }>> = {
    Monday: [
        { time: '8:30 - 9:30', subject: 'DBMS', faculty: 'Prof. Aruna Gupta' },
        { time: '9:30 - 10:30', subject: 'Computer Networks', faculty: 'Prof. Manisha Gade' },
        { time: '10:45 - 11:45', subject: 'Software Engineering', faculty: 'Prof. Swati Bagul' },
        { time: '11:45 - 12:45', subject: 'Python', faculty: 'Prof. Shraddha Katkar' },
        { time: '1:20 - 3:20', subject: 'DBMS Practical', faculty: 'Prof. Aruna Gupta' },
    ],
    Tuesday: [
        { time: '8:30 - 9:30', subject: 'Cybersecurity', faculty: 'Prof. Manisha Gade' },
        { time: '9:30 - 10:30', subject: 'C++', faculty: 'Prof. Dipti Gaikwad' },
        { time: '10:45 - 11:45', subject: 'Machine Learning', faculty: 'Dr. Sudhir Rangari' },
        { time: '11:45 - 12:45', subject: 'Python', faculty: 'Prof. Shraddha Katkar' },
        { time: '1:20 - 3:20', subject: 'Java Practical', faculty: 'Prof. Dipti Gaikwad' },
    ],
    Wednesday: [
        { time: '8:30 - 9:30', subject: 'Operating Systems', faculty: 'Prof. Aruna Gupta' },
        { time: '9:30 - 10:30', subject: 'Cloud Computing', faculty: 'Prof. Atul Halmare' },
        { time: '10:45 - 11:45', subject: 'Computer Graphics', faculty: 'Prof. Swati Bagul' },
        { time: '11:45 - 12:45', subject: 'Data Structures', faculty: 'Prof. Dipti Gaikwad' },
        { time: '1:20 - 3:20', subject: 'OS Practical', faculty: 'Prof. Aruna Gupta' },
    ],
    Thursday: [
        { time: '8:30 - 9:30', subject: 'Cloud Computing', faculty: 'Prof. Atul Halmare' },
        { time: '9:30 - 10:30', subject: 'Java', faculty: 'Prof. Dipti Gaikwad' },
        { time: '10:45 - 11:45', subject: 'Python', faculty: 'Prof. Shraddha Katkar' },
        { time: '11:45 - 12:45', subject: 'Machine Learning', faculty: 'Dr. Sudhir Rangari' },
        { time: '1:20 - 3:20', subject: 'Python Practical', faculty: 'Prof. Shraddha Katkar' },
    ],
    Friday: [
        { time: '8:30 - 9:30', subject: 'Software Engineering', faculty: 'Prof. Swati Bagul' },
        { time: '9:30 - 10:30', subject: 'Computer Networks', faculty: 'Prof. Manisha Gade' },
        { time: '10:45 - 11:45', subject: 'Data Science', faculty: 'Prof. Shraddha Katkar' },
        { time: '11:45 - 12:45', subject: 'Operating Systems', faculty: 'Prof. Aruna Gupta' },
        { time: '1:20 - 3:20', subject: 'Software Engg Practical', faculty: 'Prof. Swati Bagul' },
    ],
    Saturday: [
        { time: '8:30 - 9:30', subject: 'Machine Learning', faculty: 'Dr. Sudhir Rangari' },
        { time: '9:30 - 10:30', subject: 'C++', faculty: 'Prof. Dipti Gaikwad' },
        { time: '10:45 - 11:45', subject: 'Cybersecurity', faculty: 'Prof. Manisha Gade' },
        { time: '11:45 - 12:45', subject: 'Cloud Computing', faculty: 'Prof. Atul Halmare' },
        { time: '1:20 - 3:20', subject: 'Mini Project', faculty: 'All Faculty' },
    ],
};

// Convert facultyData to studentData with `teacher` key
const studentData: Record<string, Array<{ time: string, subject: string, teacher: string }>> = Object.fromEntries(
    Object.entries(facultyData).map(([day, schedule]) => [
        day,
        schedule.map(({ time, subject, faculty }) => ({
            time,
            subject,
            teacher: faculty,
        })),
    ])
);

export default function TimetablePage() {
    const [selectedDay, setSelectedDay] = useState('Monday');

    return (
        <div className="pt-28 px-6 lg:px-20 pb-16 bg-neutral-100 min-h-screen font-sans transition-all duration-300">
            <h1 className="text-5xl font-semibold text-center text-gray-900 mb-10 tracking-tight">📅 Timetable</h1>

            {/* Styled Dropdown */}
            <div className="flex justify-center mb-12">
                <div className="relative inline-block w-64">
                    <select
                        className="w-full appearance-none px-6 py-3 border border-gray-300 bg-white text-gray-900 font-medium rounded-lg shadow-md hover:shadow-lg focus:ring-2 focus:ring-indigo-400 focus:outline-none transition"
                        value={selectedDay}
                        onChange={(e) => setSelectedDay(e.target.value)}
                    >
                        {days.map((day) => (
                            <option key={day} value={day}>{day}</option>
                        ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-3 flex items-center px-2 text-gray-500">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                </div>
            </div>

            <div className="grid md:grid-cols-2 gap-10">
                {/* Faculty Timetable */}
                <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-200 backdrop-blur-sm">
                    <h2 className="text-xl font-semibold text-gray-800 mb-4">👩‍🏫 Faculty Timetable</h2>
                    <table className="w-full text-sm border-separate border-spacing-y-2">
                        <thead className="bg-slate-900/60 backdrop-blur-md text-white border-b border-white/10 uppercase text-xs tracking-widest rounded-lg">
                            <tr>
                                <th className="py-3 px-4 text-left">Time</th>
                                <th className="py-3 px-4 text-left">Subject</th>
                                <th className="py-3 px-4 text-left">Faculty</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(facultyData[selectedDay] ?? []).map((item, index) => (
                                <tr key={index} className="bg-gray-100 hover:bg-gray-200 transition rounded-xl">
                                    <td className="py-2 text-gray-800 px-4 rounded-l-xl">{item.time}</td>
                                    <td className="py-2 text-gray-800 px-4">{item.subject}</td>
                                    <td className="py-2 text-gray-800 px-4 rounded-r-xl">{item.faculty}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* Student Timetable */}
                <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-200 backdrop-blur-sm">
                    <h2 className="text-xl font-semibold text-gray-800 mb-4">🧑‍🎓 Student Timetable</h2>
                    <table className="w-full text-sm border-separate border-spacing-y-2">
                        <thead className="bg-slate-900/60 backdrop-blur-md text-white border-b border-white/10 uppercase text-xs tracking-widest rounded-lg">
                            <tr>
                                <th className="py-3 px-4 text-left">Time</th>
                                <th className="py-3 px-4 text-left">Subject</th>
                                <th className="py-3 px-4 text-left">Teacher</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(studentData[selectedDay] ?? []).map((item, index) => (
                                <tr key={index} className="bg-gray-100 hover:bg-gray-200 transition rounded-xl">
                                    <td className="py-2 text-gray-800 px-4 rounded-l-xl">{item.time}</td>
                                    <td className="py-2 text-gray-800 px-4">{item.subject}</td>
                                    <td className="py-2 text-gray-800 px-4 rounded-r-xl">{item.teacher}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
