import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';


const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'IT Department Portal',
  description: 'Next.js site for Engineering College',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-white text-black`}>
        <Navbar /> {/* 👈 Navbar on all pages */}
        <div className="pt-20">{children}</div> {/* Prevent content under navbar */}
        <Footer />

      </body>
    </html>
  );
}
