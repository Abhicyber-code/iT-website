


'use client';

import { useEffect } from 'react';
import Image from 'next/image';

const facultyMembers = [
    {
        name: 'Dr. Sudhir Rangari',
        designation: 'Professor & Head of Department',
        expertise: 'Machine Learning, Data Science',
        email: 'head_itjscoe@jspmjscoe.edu.in',
        img: 'https://jspmjscoe.edu.in/storage/Departments/SRRangari.jpg',
    },
    {
        name: 'Prof. Dipti Gaikwad',
        designation: 'Assistant Professor',
        expertise: 'C++, Computer Networks, Data Structures',
        email: 'diptisawant@jspmjscoe.edu.in',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/DAGaikwad.jpg',
    },
    {
        name: 'Prof. Aruna Gupta',
        designation: 'Assistant Professor',
        expertise: 'DBMS, Operating Systems',
        email: 'arunagupta@jspmjscoe.edu.in',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/AKGupta.jpg',
    },
    {
        name: 'Prof. Swati Bagul',
        designation: 'Assistant Professor',
        expertise: 'Software Engineering, Computer Graphics',
        email: 'swatiabir18@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/SABagul.jpg',
    },
    {
        name: 'Prof. Manisha Gade',
        designation: 'Assistant Professor',
        expertise: 'Cybersecurity, Computer Networks',
        email: 'manishagade23@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/Manisha.jpg',
    },
    {
        name: 'Prof. Atul Halmare',
        designation: 'Assistant Professor',
        expertise: 'Cloud Computing',
        email: 'jspmatul@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/img/faculty/6271/atul%20img.jpg',
    },
    {
        name: 'Prof. Shraddha Katkar',
        designation: 'Assistant Professor',
        expertise: 'Data Science, Python',
        email: 'shraddhasivaji99@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/ssk.png',
    },
    {
        name: 'Prof. Mokshada N. Badgujar',
        designation: 'Assistant Professor',
        expertise: 'Python, Data Structures, DBMS',
        email: 'mokshadajspm@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/photo.jfif',
    },
    {
        name: 'Prof. Nikita L Bagora',
        designation: 'Assistant Professor',
        expertise: 'Web Application Development',
        email: 'nikitabagora.29@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/WhatsApp%20Image%202025-04-03%20at%202.19.37%20PM.jpeg',
    },
    {
        name: 'Prof. Dummy 1',
        designation: 'Assistant Professor',
        expertise: 'Web Development, React',
        email: 'dummy3@jscoe.edu.in',
        img: '',
    },
    {
        name: 'Prof. Dummy 2',
        designation: 'Assistant Professor',
        expertise: 'Cybersecurity, Computer Networks',
        email: 'dummy4@jscoe.edu.in',
        img: '',
    },
];

export default function FacultyPage() {
    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate-fadeInUp');
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.1 }
        );

        const cards = document.querySelectorAll('.animate-on-scroll');
        cards.forEach((card) => observer.observe(card));

        return () => observer.disconnect();
    }, []);

    return (
        <div className="pt-24 px-6 lg:px-20 pb-12 bg-gray-50 min-h-screen">
            <h1 className="text-4xl font-bold text-center text-blue-900 mb-4">Our Faculty</h1>
            <p className="text-center text-gray-600 mb-10 max-w-2xl mx-auto">
                Meet the highly experienced and dedicated faculty members of the IT Department, JSCOE.
            </p>

            <div className="grid gap-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                {facultyMembers.map((faculty, index) => (
                    <div
                        key={index}
                        className="bg-white shadow-lg rounded-xl overflow-hidden hover:shadow-xl transition duration-300 opacity-0 animate-on-scroll"
                    >
                        {faculty.img ? (
                            <Image
                                src={faculty.img}
                                alt={faculty.name}
                                width={500}
                                height={500}
                                className="w-full h-60 object-cover"
                            />
                        ) : (
                            <div className="w-full h-60 bg-gray-200 flex items-center justify-center text-gray-500 text-sm">
                                No Image
                            </div>
                        )}
                        <div className="p-4">
                            <h2 className="text-xl font-semibold text-blue-800">{faculty.name}</h2>
                            <p className="text-sm text-gray-600">{faculty.designation}</p>
                            <p className="mt-2 text-sm text-gray-700">
                                <strong>Expertise:</strong> {faculty.expertise}
                            </p>
                            <p className="text-sm text-gray-600 mt-1">
                                <strong>Email:</strong> {faculty.email}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
