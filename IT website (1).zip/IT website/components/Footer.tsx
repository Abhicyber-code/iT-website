// components/Footer.tsx
import Link from 'next/link';

export default function Footer() {
    return (
        <footer className="bg-blue-950 text-white py-6 mt-16">
            <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h4 className="text-lg font-semibold mb-2">About JSCOE IT Department</h4>
                    <p className="text-sm text-gray-300">
                        Empowering students with cutting-edge tech education and industry exposure.
                    </p>
                </div>
                <div>
                    <h4 className="text-lg font-semibold mb-2">Quick Links</h4>
                    <ul className="text-sm text-gray-300 space-y-1">
                        <li><Link href="/" className="hover:underline">Dashboard</Link>
                        </li>
                        <li><Link href="/Faculty" className="hover:underline">Faculty</Link></li>
                        <li><Link href="/Alumni" className="hover:underline">Alumni</Link></li>
                        <li><Link href="/ITSA" className="hover:underline">ITSA</Link></li>
                    </ul>
                </div>
                <div>
                    <h4 className="text-lg font-semibold mb-2">Contact Us</h4>
                    <p className="text-sm text-gray-300">JSPM's JSCOE, Hadapsar, Pune</p>
                    <p className="text-sm text-gray-300">Email: itdept@jscoe.edu.in</p>
                    <p className="text-sm text-gray-300">Phone: +91-1234567890</p>
                </div>
            </div>
            <div className="text-center text-gray-400 text-xs mt-6">
                © {new Date().getFullYear()} IT Department, JSCOE. All rights reserved. Designed and developed by Abhijeet Gitte
            </div>
        </footer>
    );
}
