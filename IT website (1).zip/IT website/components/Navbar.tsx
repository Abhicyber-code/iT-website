

'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Menu, X, LogOut } from 'lucide-react';
import Image from 'next/image';

const navLinks = [
    { title: 'Home', href: '/' },
    { title: 'Faculty', href: '/Faculty' },
    { title: 'About', href: '/About' },
    { title: 'Timetable', href: '/Timetable' },
    { title: 'Alumni', href: '/Alumni' },
    { title: 'ITSA', href: '/ITSA' },
];

export default function Navbar() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <header className="fixed top-0 z-50 w-full backdrop-blur-xl bg-white/80 shadow-md border-b border-gray-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center h-16">
                    {/* Logo + Title */}
                    <Link href="/" className="flex items-center gap-3">
                        <Image
                            src="https://jspmjscoe.edu.in/storage/Logo/JSCOE_logo.png"
                            alt="JSCOE Logo"
                            width={40}
                            height={40}
                            className="rounded-lg shadow-sm"
                        />
                        <span className="text-lg sm:text-xl font-semibold text-gray-900 tracking-tight hover:scale-[1.03] transition">
                            JSCOE | IT Department
                        </span>
                    </Link>

                    {/* Desktop Menu */}
                    <nav className="hidden md:flex items-center space-x-6">
                        {navLinks.map((link) => (
                            <Link
                                key={link.title}
                                href={link.href}
                                className="text-gray-700 hover:text-blue-600 transition font-medium text-sm sm:text-base"
                            >
                                {link.title}
                            </Link>
                        ))}

                        {/* Logout with Logo */}
                        <button
                            onClick={() => alert('Logout logic goes here')}
                            className="ml-4 hover:scale-105 transition"
                            title="Logout"
                        >
                            <LogOut className="text-red-500 hover:text-red-600" size={24} />
                        </button>
                    </nav>

                    {/* Mobile Hamburger */}
                    <div className="md:hidden">
                        <button
                            onClick={() => setIsOpen(!isOpen)}
                            className="text-gray-800 hover:text-blue-600 transition"
                        >
                            {isOpen ? <X size={28} /> : <Menu size={28} />}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            {isOpen && (
                <div className="md:hidden bg-white/90 backdrop-blur-xl shadow-lg border-t border-gray-200 px-4 py-4 space-y-3 transition-all duration-300">
                    {navLinks.map((link) => (
                        <Link
                            key={link.title}
                            href={link.href}
                            onClick={() => setIsOpen(false)}
                            className="block text-gray-800 hover:text-blue-600 font-medium text-base"
                        >
                            {link.title}
                        </Link>
                    ))}
                    <button
                        onClick={() => {
                            setIsOpen(false);
                            alert('Logout logic goes here');
                        }}
                        className="flex items-center gap-2 text-red-600 hover:text-red-700 font-medium mt-2"
                    >
                        <LogOut size={20} /> Logout
                    </button>
                </div>
            )}
        </header>
    );
}
