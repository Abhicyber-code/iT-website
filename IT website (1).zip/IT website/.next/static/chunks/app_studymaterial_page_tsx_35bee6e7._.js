(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_studymaterial_page_tsx_35bee6e7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_studymaterial_page_tsx_35bee6e7._.js",
  "chunks": [
    "static/chunks/_3b0721c6._.js"
  ],
  "source": "dynamic"
});
