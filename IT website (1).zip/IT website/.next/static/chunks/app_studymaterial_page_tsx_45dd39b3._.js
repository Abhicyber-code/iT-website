(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_studymaterial_page_tsx_45dd39b3._.js", {

"[project]/app/studymaterial/page.tsx [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
'use client';
'use client';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_studymaterial_page_tsx_45dd39b3._.js.map