(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_d14a9d17._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_d14a9d17._.js",
  "chunks": [
    "static/chunks/app_page_tsx_8221feda._.js"
  ],
  "source": "dynamic"
});
