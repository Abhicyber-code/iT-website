(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_b741fd61._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_b741fd61._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_ea69acce._.js"
  ],
  "source": "dynamic"
});
