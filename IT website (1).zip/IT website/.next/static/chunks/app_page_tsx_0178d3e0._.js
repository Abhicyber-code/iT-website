(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_0178d3e0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_0178d3e0._.js",
  "chunks": [
    "static/chunks/node_modules_framer-motion_dist_es_9d1196c1._.js",
    "static/chunks/node_modules_motion-dom_dist_es_7fc0833b._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_78df2b41._.js",
    "static/chunks/node_modules_react-icons_si_index_mjs_4ff16b17._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_motion-utils_dist_es_e1ba5b02._.js",
    "static/chunks/app_page_tsx_8221feda._.js"
  ],
  "source": "dynamic"
});
