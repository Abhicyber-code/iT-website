(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_ITSA_page_tsx_35bee6e7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_ITSA_page_tsx_35bee6e7._.js",
  "chunks": [
    "static/chunks/_54ab151b._.js"
  ],
  "source": "dynamic"
});
