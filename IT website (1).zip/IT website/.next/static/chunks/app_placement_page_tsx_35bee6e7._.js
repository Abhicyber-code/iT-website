(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_placement_page_tsx_35bee6e7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_placement_page_tsx_35bee6e7._.js",
  "chunks": [
    "static/chunks/_4baaa1ed._.js"
  ],
  "source": "dynamic"
});
