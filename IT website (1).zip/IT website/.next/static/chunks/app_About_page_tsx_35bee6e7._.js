(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_About_page_tsx_35bee6e7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_About_page_tsx_35bee6e7._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_5eec24f3._.js"
  ],
  "source": "dynamic"
});
