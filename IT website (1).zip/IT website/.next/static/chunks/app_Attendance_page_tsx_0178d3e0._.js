(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Attendance_page_tsx_0178d3e0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Attendance_page_tsx_0178d3e0._.js",
  "chunks": [
    "static/chunks/_c8329138._.js"
  ],
  "source": "dynamic"
});
