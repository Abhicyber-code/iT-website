(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Faculty_page_tsx_0178d3e0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Faculty_page_tsx_0178d3e0._.js",
  "chunks": [
    "static/chunks/app_Faculty_page_tsx_3ebdb22c._.js"
  ],
  "source": "dynamic"
});
