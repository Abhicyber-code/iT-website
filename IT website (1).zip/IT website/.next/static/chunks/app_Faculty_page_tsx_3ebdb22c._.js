(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_Faculty_page_tsx_3ebdb22c._.js", {

"[project]/app/Faculty/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>FacultyPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const facultyMembers = [
    {
        name: 'Dr. Sudhir Rangari',
        designation: 'Professor & Head of Department',
        expertise: 'Machine Learning, Data Science',
        email: 'head_itjscoe@jspmjscoe.edu.in',
        img: 'https://jspmjscoe.edu.in/storage/Departments/SRRangari.jpg'
    },
    {
        name: 'Prof. Dipti Gaikwad',
        designation: 'Assistant Professor',
        expertise: 'C++, Computer Networks, Data Structures',
        email: 'diptisawant@jspmjscoe.edu.in',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/DAGaikwad.jpg'
    },
    {
        name: 'Prof. Aruna Gupta',
        designation: 'Assistant Professor',
        expertise: 'DBMS, Operating Systems',
        email: 'arunagupta@jspmjscoe.edu.in',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/AKGupta.jpg'
    },
    {
        name: 'Prof. Swati Bagul',
        designation: 'Assistant Professor',
        expertise: 'Software Engineering, Computer Graphics',
        email: 'swatiabir18@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/SABagul.jpg'
    },
    {
        name: 'Prof. Manisha Gade',
        designation: 'Assistant Professor',
        expertise: 'Cybersecurity, Computer Networks',
        email: 'manishagade23@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/Manisha.jpg'
    },
    {
        name: 'Prof. Atul Halmare',
        designation: 'Assistant Professor',
        expertise: 'Cloud Computing',
        email: 'jspmatul@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/img/faculty/6271/atul%20img.jpg'
    },
    {
        name: 'Prof. Shraddha Katkar',
        designation: 'Assistant Professor',
        expertise: 'Data Science, Python',
        email: 'shraddhasivaji99@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/ssk.png'
    },
    {
        name: 'Prof. Mokshada N. Badgujar',
        designation: 'Assistant Professor',
        expertise: 'Python, Data Structures, DBMS',
        email: 'mokshadajspm@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/photo.jfif'
    },
    {
        name: 'Prof. Nikita L Bagora',
        designation: 'Assistant Professor',
        expertise: 'Web Application Development',
        email: 'nikitabagora.29@gmail.com',
        img: 'https://jspmjscoe.edu.in/storage/Faculty/4/WhatsApp%20Image%202025-04-03%20at%202.19.37%20PM.jpeg'
    },
    {
        name: 'Prof. Dummy 1',
        designation: 'Assistant Professor',
        expertise: 'Web Development, React',
        email: 'dummy3@jscoe.edu.in',
        img: ''
    },
    {
        name: 'Prof. Dummy 2',
        designation: 'Assistant Professor',
        expertise: 'Cybersecurity, Computer Networks',
        email: 'dummy4@jscoe.edu.in',
        img: ''
    }
];
function FacultyPage() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FacultyPage.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "FacultyPage.useEffect": (entries)=>{
                    entries.forEach({
                        "FacultyPage.useEffect": (entry)=>{
                            if (entry.isIntersecting) {
                                entry.target.classList.add('animate-fadeInUp');
                                observer.unobserve(entry.target);
                            }
                        }
                    }["FacultyPage.useEffect"]);
                }
            }["FacultyPage.useEffect"], {
                threshold: 0.1
            });
            const cards = document.querySelectorAll('.animate-on-scroll');
            cards.forEach({
                "FacultyPage.useEffect": (card)=>observer.observe(card)
            }["FacultyPage.useEffect"]);
            return ({
                "FacultyPage.useEffect": ()=>observer.disconnect()
            })["FacultyPage.useEffect"];
        }
    }["FacultyPage.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "pt-24 px-6 lg:px-20 pb-12 bg-gray-50 min-h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-4xl font-bold text-center text-blue-900 mb-4",
                children: "Our Faculty"
            }, void 0, false, {
                fileName: "[project]/app/Faculty/page.tsx",
                lineNumber: 111,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-center text-gray-600 mb-10 max-w-2xl mx-auto",
                children: "Meet the highly experienced and dedicated faculty members of the IT Department, JSCOE."
            }, void 0, false, {
                fileName: "[project]/app/Faculty/page.tsx",
                lineNumber: 112,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-10 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
                children: facultyMembers.map((faculty, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white shadow-lg rounded-xl overflow-hidden hover:shadow-xl transition duration-300 opacity-0 animate-on-scroll",
                        children: [
                            faculty.img ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: faculty.img,
                                alt: faculty.name,
                                width: 500,
                                height: 500,
                                className: "w-full h-60 object-cover"
                            }, void 0, false, {
                                fileName: "[project]/app/Faculty/page.tsx",
                                lineNumber: 123,
                                columnNumber: 29
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full h-60 bg-gray-200 flex items-center justify-center text-gray-500 text-sm",
                                children: "No Image"
                            }, void 0, false, {
                                fileName: "[project]/app/Faculty/page.tsx",
                                lineNumber: 131,
                                columnNumber: 29
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-xl font-semibold text-blue-800",
                                        children: faculty.name
                                    }, void 0, false, {
                                        fileName: "[project]/app/Faculty/page.tsx",
                                        lineNumber: 136,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600",
                                        children: faculty.designation
                                    }, void 0, false, {
                                        fileName: "[project]/app/Faculty/page.tsx",
                                        lineNumber: 137,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 text-sm text-gray-700",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: "Expertise:"
                                            }, void 0, false, {
                                                fileName: "[project]/app/Faculty/page.tsx",
                                                lineNumber: 139,
                                                columnNumber: 33
                                            }, this),
                                            " ",
                                            faculty.expertise
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/Faculty/page.tsx",
                                        lineNumber: 138,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600 mt-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: "Email:"
                                            }, void 0, false, {
                                                fileName: "[project]/app/Faculty/page.tsx",
                                                lineNumber: 142,
                                                columnNumber: 33
                                            }, this),
                                            " ",
                                            faculty.email
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/Faculty/page.tsx",
                                        lineNumber: 141,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/Faculty/page.tsx",
                                lineNumber: 135,
                                columnNumber: 25
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/app/Faculty/page.tsx",
                        lineNumber: 118,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/Faculty/page.tsx",
                lineNumber: 116,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/Faculty/page.tsx",
        lineNumber: 110,
        columnNumber: 9
    }, this);
}
_s(FacultyPage, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = FacultyPage;
var _c;
__turbopack_context__.k.register(_c, "FacultyPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_Faculty_page_tsx_3ebdb22c._.js.map