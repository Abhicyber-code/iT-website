(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__26c7fb5b._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_90acbfa8._.js",
    "static/chunks/node_modules_38374544._.js",
    "static/chunks/components_Navbar_tsx_c69926eb._.js"
  ],
  "source": "dynamic"
});
