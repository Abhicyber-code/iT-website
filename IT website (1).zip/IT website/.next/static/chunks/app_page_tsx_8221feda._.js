(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_page_tsx_8221feda._.js", {

"[project]/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/md/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$si$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/si/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function Home() {
    _s();
    const studentInfo = {
        name: 'Welcome to IT Department',
        class: 'JSPM’s Jayawantrao Sawant College of Engineering',
        roll: 'Explore Our Digital Portal',
        profilePic: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABDlBMVEX////gn2c0aYRRPjb09PQrOEGtd1PjoWj29vYxZ4P6+fj8/Pzfm1/fnGLmo2lLOjQhYH1GNzPm6etFLiRLNy5BKR7emFpBcotJNCvkq3sdXnxiSTvcnGbpu5b25dfOkWC3f1fQ2+EVJzOUiobX09LCilzz2sf78uvipG/qwJ7lsIOye1WPqLZsjqG6yNAjMTtMeZGyq6iEeHO8trRnV1FcS0OMgX3RzMuKZEl1VkJgSDuCX0btyaz57OKxwcrh6OyHorGipqm7vsALIS5mbnMtQk5gh5ylnZt4a2Y8IhTj4eCidFFZR0CVbE3w0rrcuZ+scUe+j3CFi49IUll2fIFXYGecoKMxWG0uS1qgtcGIzcjzAAAOGElEQVR4nO2da1fayh7GDUYTEi7hoiCigIqXIkjVVm0r0F2L3bZ2n9N2n5bv/0XOTK4zyYRMkkkmrOXzqqvIZH75X2cm0bW1F73oRS960Yte9KIXvWhNlZ+uXj8eXl5+uXx7+Pj66qYqq7znxFBPV4fXta1as9ms62o2a7Wt+vXbx5snhffcGEh8fV2v1evrXtWbteb15dUT7xnG09Nls0aiczBrtW+HN7ynGVlPl38vxTMFbPn2ZhX9VX1s0vAZptx687hy7vp0XaPlMyxZvzziPedQutmiNqBjyOsVYny9FZbPYPyyKr4aDRAy1g5F3pOn0VVUQKDm+hXv6QfrKFyOcWvrMutmFN+ETjIuM77JeMY5bMYDhNGYaU99ihGEtrYeeWMs0ZeYPmqo9pY3h6+YmBAiXvIm8dNbJiZcz64VRUZ8EPGQNwxRN/FqIaat17xpSHqMXSpQxCzWRWZhaEjmzYNLPbq6YlMrLDWzlVCvrrdqy3dlwitLzY16GX7NS6FvmdnAka9ZphhHzcyUjC/JAK6v/13ljWbokGEZxFXPRmtzxKgZJamZia2b6ySSjEWYhUi8SsxHdWVgUyNJE4KayL89vUkwCoHq17wB1y4TNSEoGLxzjZqsCUGu4b1pw3JJSBZvNz1M2ElBruHc17xJGnC99hdXwCrJhOXBbpkdIefOjXhKUem337FD5FwviA1NpV9qs7Qi10AkHlNUOpLUvquwAqxx3ZIi1vtKRxAE6ZYVIt/NDPLeUxsQCqVNRo7KtearxLZ7V9BV6rMJxjrPPTflmjCj8vuSgSi1mXhq/QvHB/1EUsEvf5UEU6XuOgMzvuG45UYm7NiEgiTclmMz1jmugsVvhAntOoB6NMauG1s8CQk2rHQxQkGSurvxGLc4LhFlAuFuSXBJkgbv4jDyPIVSvbm00pfchICx1L2LHo9cz9k8Fb98RwDU7di/LUc0ZI3nU7Zewg6ZENqx83W3EsWQXAndZ6LlW08U4pC36+G9lSuh51y7vQRQZ5T6z2EtyZXQtT6sfF1mQgtS6H+9K4eg5Lp8cq/xA/ksS7a7t+sVSkquufQJi8PKwC/NkChLgHJ3vRIclzwr/toaOhO/SrGMstN/vnsXYEyeXRteLojFnsaWnc3b3Yo/ZpMrIZJMy3fBacaHEgSm0B/cvisTE9A3rg/WIMm04lvsaTFL7f7X997QvOb6SEbVPpmxl/YxMaUOxER8tv6FJyCSamKaEMcU2t3nu4rRx/Lc9Fa+7xTem/d6eb8WAbNUErr6Vlb5uXS2zwfwuFgoSpvmgsG/5Y5BKdyV4b5Pqbj96oQD4IdtOIlOJRETmojtXXPToCikj/h925jFbmImhIjdijl08TTtjHpiApaey7FqYYDa76z1SmEvZcK9onmX+5Wo7QyNSndla++ucJ8q4EkBvcvr7xIyoVC6rVjuUTxLlXC/4MyhDNaFCZlQkL5Wnq27t5Mq4bFNCN20HLC0j0E4QPZfOREKEmjYkjIhTKZ2lj5NldDxUhgqIVa+4QntEE/XS08QG3bYtaQEQrsOFVMuF+gs7hILQ0D4bN29wvd0Cc+Kziz6iQGCTGMnmkLKfdv+dnJYKGHX8o/iq3QB19Z2UiEUOhZh4ThtwuN0jGgr3Vqha6cYPC122k7dhFhJTF7FdIuhqbMUEdNOpKZOU/PT7ZRroaX7tIyY+urXVkqhmH4pdHScBmJhh+fvd9vfTjwWC6/4vmh5f5qsGYvbH7jyAakfioXE7Fgs7HDa7sZ08iGxHnUvC3y6ksk4nMo8WUkQpr2oX66zBEIx/fXSMt0nsJZK/aRiuV4xN2KBe5nAxb6BK2Ypz0CxXhCnfExBIdYFYztrJgSrRaaA2SoVhthuTWWq2ltiacTsRSEUSyNmLpEaYlcTs1YLLd2zKxi8UfzEan+Rx/YvpdgAZrFSWGJ0IpXNNGOIhZ9ma9XklhJ/HzzLPgrFYB8863/94nvMUEz54a4o2otlxbSfR4ikOCvFQib7UbdiZBt+h0zhdCJEROR5yBRO9xEBd7K1u7ZM91GsuEqAwFHDx2JhZVzU0MlOyKKxKknGkboXqvTzPyaMoO8hHDXb3bav/ilSPncqtf+TmYPCUPrvJuWjtf3N/mrasD3Y7LYDGaXOYLOfzd3DIN0XgXECGCWh092Epubw6GF8HReAfTYBY0fwgTT4dF/O6AbpcsEXh6Q2RBj025IbEvxHpz+AH+pGXsVkqpyaYba5qUPCp30lQ+C/27r1oIUN4KzvXZBk7btJMBoNDbrdPlC3O7D/x3lfZJWaUkPOWl9q24wu9Z00lOFdYD+hz4ORGdE0W9hZxVRzhnSmZtp0NOijZWR7JeshqBfoMlGS2p2+EYGDbr+NVpCisHouauretYYCabQNJOC1o8DlTW1WOgteQ63kwgnRccCGRlFYzWUFopNXy1b7fH6XAGst8dRV91BL+z6eWjxdQQ9VZdLvyyF76vYeoVMDA6iZPX2aTuY9WRSJvxLog9dTyYcwYABlMp9Mk51qFE0X47zWGimiKBJNsF/EPbUoEI/RVPB95byl5ceLXrITDiW1N8uDSeVy2gISkn+vk4J5qt/2qAwJh/lcHtwubTbKxN9eq06GuRagg8rPICHZiMBTbcRi0eeYUP+6PLeGa+WHE85/G2G6mOc1cz5wSnNjij4/beXUwqnfQa/+7Woj54yo5ecLbkHZO29oCB6cT6MK3Uz0W80anrq955cs9S/LPS2HDappjfP0g1IczbQWjgelTfVJ+v8Oue8FXw810gxMpZp7WBiUw1GKv5luOhnmvXQ64cgg9M8Q+6/8H0UwvqvMiEODXDZMp4j0zsc+eJDwXA9E32QDKB58RzZM6CQaL6SmjZP2V7XXAqHnNwOYamRxuREfPv3w+8g0v+hxUhyy1Uuq51EVmRQjLiNW5aVG/HiwceDzl2NM6yujVsAlJrIoK+wpVSNJLoIIzUD0STZHBxsbGxfkEmd+zycMkUssjJLEmFGmvLxZ830qhroBdfFzyRVEtUF7CZYNj5kDjIYq4PoWIclPHy50xANCKFqXcFdDwhWGyy4RE1BUxkGErZ5lDO8t/niwYYgQita3AuMglx/bhKwQHUBRDHIhxE09lz+yAIHcoeh4SeA9zI9lkS0iAoi1jD7Xb4g+RpQ/X9iAnlC0r9ALAszlGlXGiMhw8jTw8kg2dSWbBwfQE4q23ZXzICcFmqJTig/oOD3dHUYSAVYxPiI+CvQJC0X7AsFhAK7QQwh9u3x6iRghxR3OO06E3OAjHBAPRecLQeUeSsMIY/fj2GDyiILQ7k3RKEGD0ApF+0MkV/v2pOgFRvik4gGieZS4sCFJ9BrxwQ2IhqLz4z0KE4K2TcFmFS/ZYHeLoli5Z2Bd/aeX8OKX5y4GNxT6+AucMJ4RsaHoMh0oGIrr6qrsDcOLz1XZdQ156rsswwjPccJYkegaKrAtNaeAGFFPdbKo/uVGvDhSDH7kZ2dUQYA0Fcg1Ikp2DUXlRaDrcCJRNEdRfriqxUfVMLHjo/KUanSsHsV1UzzPUBNiRpTNLULlAUX89MMYW0VuIqUJvYQxco3LhEs2GFxzaCBGtDYnZCSfXvywF1nO4DTFVh997pkXM0IxsC025UkGcBpPjhE/i56h6WqhTjj2DB0V0O2kMjVhXqt6EBSkbzs48n5M085YhO5vR3VTtx3A0oKSEMSK+/aIyi/HSw/+5xmbpiP1JYyaTT3uHrx4sqWN3AlPREvFg2eOVKXWUMPjIFHd1G0FuUo9CXuD3/ny0ScU0WUGkGZoTUgijFj0PX4WhjCnueqygi2fPuGBSB/huryE0QLRkw5DEeZauJ+q/2Ir4I/Yh7Sl0JcwWiB6hpGrYW50Dsunsoj1NBf/oh5Cn0f9CKMFonuUsISgMiMNi6sxPUA+C5GjjYG9hJEC0ROGYQnxtfAPfP10cOOsCmXKZnAZYZRA9I4SlhANRcW1QkQqYphC4UsYxU09g4QntE9MQcvmWgI7gahMwgVhtgjtqugOQyDrE9qGGxGBMEIgelvnkNXCQDSzjfrLvY1hBqISMsv4EoavF4RBIhDmtCFElMWfbhNe6IEYNo3qIvQ0UdyUSEjflzqIsLfBWzaD8EEO3cswJfTWiog3XK8ZykdPGMJAlMV5+CD0tryGwtYLQhhGvOMQUSHtl94o4jACIGn1BBU2EEljiCLtMhxX61wmmBAEYhQLwuxFnFtYNyUPEo0QpBuvCUFFjGRB0j6NIRaEtHtt3kn99hJu/I46mGevLRIhKdNEJ8zlPIifo47k3RE2FL4zJVVVuj1v8rxYAZIJIy2fCBt+YXtkbGKfEcA/0cfxnMxEBiR4Kt3Zk6/+OCEYZxgCIbNNb6oT0iX6zQLQfUIa83hNxTeMIqwDMOme+id6MBuE+Cl37Me/sCcVKE+HluhPTANCoc9iMHhSAWWM1HozF9qWsnp7WLEfAorUmLIV8kwUy7ejTUbq86EkCY0XAkSZ9dvfes6JU/KZEeoFn/XjpYYUmfJxk0SlTRTm5kPUs9+P4aR8K5/ws+xyb5YjvGiRDp3Wys16abx2Ybwsky4lfNUr1VdnpqNhepR5+GJQSq+ToFKnk9m4pSXsscB0rfFsMuX1Xqkq9hZzMIckrAn9spWfn4+q/N+arY4WwwbwJMDJAjSf18dqDBcjzi8f4pKnvcVsPs5prYioBlhLy43ns0VvmonXRwlSxWlvtDgfAtQWkKYZuCRi47/1n4A/CsCGs8WoN2X3FkXCAl0egB1NFovZbDicz8fjRsNamYB/jcfz+XA4O18sJiOIlUwXBvV/elu4CIo8uhwAAAAASUVORK5CYII='
    };
    const features = [
        {
            title: 'Attendance',
            href: '/Attendance',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaCalendarCheck"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 30,
                columnNumber: 55
            }, this),
            gradient: 'from-green-300 to-green-500'
        },
        {
            title: 'Timetable',
            href: '/Timetable',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MdSchedule"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 31,
                columnNumber: 53
            }, this),
            gradient: 'from-blue-300 to-blue-500'
        },
        {
            title: 'Moodle',
            href: 'https://lms.jspmjscoe.edu.in/',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$si$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SiMoodle"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 32,
                columnNumber: 69
            }, this),
            gradient: 'from-orange-300 to-orange-500'
        },
        {
            title: 'Study Material',
            href: '/studymaterial',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaBook"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 33,
                columnNumber: 62
            }, this),
            gradient: 'from-purple-300 to-purple-500'
        },
        {
            title: 'Placement & Research',
            href: '/placement',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaLaptopCode"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 34,
                columnNumber: 64
            }, this),
            gradient: 'from-cyan-300 to-cyan-500'
        },
        {
            title: 'Faculty',
            href: '/Faculty',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChalkboardTeacher"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 35,
                columnNumber: 49
            }, this),
            gradient: 'from-pink-300 to-pink-500'
        },
        {
            title: 'Alumni',
            href: '/Alumni',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaUserGraduate"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 36,
                columnNumber: 47
            }, this),
            gradient: 'from-rose-300 to-rose-500'
        },
        {
            title: 'ITSA',
            href: '/ITSA',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaUsers"], {
                size: 32
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 37,
                columnNumber: 43
            }, this),
            gradient: 'from-indigo-300 to-indigo-500'
        }
    ];
    const techLogos = [
        {
            name: 'Python',
            url: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg'
        },
        {
            name: 'Java',
            url: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg'
        },
        {
            name: 'React',
            url: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg'
        },
        {
            name: 'Machine Learning',
            url: 'https://cdn-icons-png.flaticon.com/512/595/595105.png'
        },
        {
            name: 'SQL',
            url: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg'
        },
        {
            name: 'MongoDB',
            url: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg'
        },
        {
            name: 'C++',
            url: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg'
        },
        {
            name: 'Computer Networks',
            url: 'https://cdn-icons-png.flaticon.com/512/4072/4072588.png'
        },
        {
            name: 'Big Data',
            url: 'https://cdn-icons-png.flaticon.com/512/6191/6191660.png'
        }
    ];
    const notices = [
        'Mid-Term Exam starts from 15th April',
        'Internship Drive on 10th April',
        'ITSA Meet on 20th April',
        'Project Demo Day – 25th April'
    ];
    const testimonials = [
        {
            name: 'Sneha Kulkarni',
            role: 'Placed at TCS',
            text: 'The department helped me grow technically and professionally.'
        },
        {
            name: 'Rohit Deshmukh',
            role: 'MS in Germany',
            text: 'Strong guidance and practical exposure prepared me for higher studies.'
        },
        {
            name: 'Aditi Patil',
            role: 'Software Engineer, Infosys',
            text: 'Excellent lab infrastructure and mentorship throughout the course.'
        }
    ];
    const noticesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const testimonialsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scroll = (ref, direction)=>{
        if (ref.current) {
            const scrollAmount = 300;
            ref.current.scrollBy({
                left: direction === 'left' ? -scrollAmount : scrollAmount,
                behavior: 'smooth'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gradient-to-br from-[#f6f9ff] to-[#eaf2fa] px-4 sm:px-6 md:px-24 py-10 text-gray-800 font-sans",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: -30
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.6
                },
                className: "flex flex-col sm:flex-row items-center gap-6 mb-14 backdrop-blur-lg p-6 rounded-2xl bg-white/60 shadow-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: studentInfo.profilePic || 'https://ui-avatars.com/api/?name=IT+Dept',
                        alt: "Profile",
                        className: "rounded-full w-24 h-24 object-cover border-4 border-white shadow-lg"
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center sm:text-left",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight",
                                children: studentInfo.name
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 91,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-lg text-gray-600",
                                children: studentInfo.class
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-md text-gray-500",
                                children: studentInfo.roll
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 93,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 79,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0
                },
                whileInView: {
                    opacity: 1
                },
                transition: {
                    duration: 0.6
                },
                viewport: {
                    once: true
                },
                className: "bg-white/70 border border-yellow-300 p-4 rounded-xl mb-14 shadow-md",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("marquee", {
                    className: "text-base font-semibold text-yellow-800 tracking-wide",
                    children: "📢 Mid-Term Exam from 15th April | 💼 Internship Drive – 10th April | 🎓 ITSA Meet – 20th April!"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: 40
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.6
                },
                viewport: {
                    once: true
                },
                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 sm:gap-8 mb-20",
                children: features.map((feature, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        whileHover: {
                            scale: 1.08
                        },
                        transition: {
                            type: 'spring',
                            stiffness: 300
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: feature.href,
                            className: `rounded-3xl shadow-xl hover:shadow-2xl transition-transform text-white p-8 sm:p-6 text-center bg-gradient-to-br ${feature.gradient} min-h-[160px] flex flex-col items-center justify-center`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-3",
                                    children: feature.icon
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 124,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg sm:text-xl font-semibold",
                                    children: feature.title
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 125,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 120,
                            columnNumber: 13
                        }, this)
                    }, feature.title, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 119,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: 40
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.6
                },
                viewport: {
                    once: true
                },
                className: "mb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold text-yellow-700",
                                children: "📌 Notices / Circulars"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 140,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>scroll(noticesRef, 'left'),
                                        className: "btn-glass",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChevronLeft"], {}, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 142,
                                            columnNumber: 86
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 142,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>scroll(noticesRef, 'right'),
                                        className: "btn-glass",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChevronRight"], {}, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 143,
                                            columnNumber: 87
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 143,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 141,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: noticesRef,
                        className: "overflow-x-auto flex space-x-4 p-4 bg-yellow-50 rounded-xl shadow-inner scrollbar-hide",
                        children: notices.map((notice, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-yellow-200 text-yellow-900 font-semibold px-6 py-4 rounded-lg shadow-md min-w-[250px]",
                                children: [
                                    "🔔 ",
                                    notice
                                ]
                            }, i, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 148,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 146,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 132,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: 40
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.6
                },
                viewport: {
                    once: true
                },
                className: "mb-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between items-center mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold text-blue-700",
                                children: "💬 Testimonials"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 164,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>scroll(testimonialsRef, 'left'),
                                        className: "btn-glass",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChevronLeft"], {}, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 166,
                                            columnNumber: 91
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 166,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>scroll(testimonialsRef, 'right'),
                                        className: "btn-glass",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChevronRight"], {}, void 0, false, {
                                            fileName: "[project]/app/page.tsx",
                                            lineNumber: 167,
                                            columnNumber: 92
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 167,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 165,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: testimonialsRef,
                        className: "overflow-x-auto flex space-x-4 p-4 bg-blue-50 rounded-xl shadow-inner scrollbar-hide",
                        children: testimonials.map((t, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                whileHover: {
                                    scale: 1.05
                                },
                                className: "bg-white p-6 rounded-xl shadow-md min-w-[280px] max-w-[300px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "italic mb-4 text-gray-600",
                                        children: [
                                            '"',
                                            t.text,
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 177,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-bold text-blue-800",
                                        children: t.name
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 178,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-600",
                                        children: t.role
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 179,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, idx, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 172,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 156,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                initial: {
                    opacity: 0,
                    y: 40
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 0.6
                },
                viewport: {
                    once: true
                },
                className: "mb-16",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-green-800 mb-6",
                        children: "🧠 Technologies We Teach"
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 193,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-6 bg-white/70 rounded-2xl p-6 shadow-lg backdrop-blur-md",
                        children: techLogos.map((tech, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                whileHover: {
                                    scale: 1.1
                                },
                                transition: {
                                    type: 'spring',
                                    stiffness: 300
                                },
                                className: "flex flex-col items-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: tech.url,
                                        alt: tech.name,
                                        className: "h-14 w-14 object-contain mb-2"
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 202,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm font-medium text-gray-700 text-center",
                                        children: tech.name
                                    }, void 0, false, {
                                        fileName: "[project]/app/page.tsx",
                                        lineNumber: 203,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 196,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 186,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, this);
}
_s(Home, "R2ptZApXxanDpI61ENuvsCdkQEc=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_page_tsx_8221feda._.js.map