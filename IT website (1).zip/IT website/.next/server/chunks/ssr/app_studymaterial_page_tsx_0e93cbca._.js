module.exports = {

"[project]/app/studymaterial/page.tsx [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
'use client';
'use client';
}}),

};

//# sourceMappingURL=app_studymaterial_page_tsx_0e93cbca._.js.map