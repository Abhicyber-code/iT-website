module.exports = {

"[project]/app/Attendance/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// 'use client';
// import { useState } from 'react';
// import { CheckCircle, XCircle } from 'lucide-react';
// const studentsList = [
//     'Aarav Patil', 'Sneha Deshmukh', 'Rohan Jadhav', 'Pooja Shinde', 'Omkar Pawar',
//     'Prachi Kale', 'Tanmay More', 'Rutuja Chavan', 'Sahil Gaikwad', 'Shruti Joshi',
//     'Kunal Salunkhe', 'Isha Kadam', 'Pratik Naik', 'Neha Bhosale', 'Aniket Lokhande',
//     'Vaishnavi Phadke', 'Aditya Gite', 'Manasi Thakur', 'Sanket Raut', 'Komal Wagh',
//     'Nikhil Khot', 'Sayali Shingade', 'Tushar Zende', 'Megha Wavhal', 'Jay Pingle',
//     'Asmita Gawade', 'Saurabh Bhujbal', 'Diksha Bane', 'Shubham Rane', 'Ketaki Khare',
// ].map((name, index) => ({ id: index + 1, name }));
// export default function AttendancePage() {
//     const [attendance, setAttendance] = useState({});
//     const [visibleCount, setVisibleCount] = useState(10);
//     const toggleAttendance = (id) => {
//         setAttendance((prev) => ({
//             ...prev,
//             [id]: !prev[id],
//         }));
//     };
//     const handleSubmit = () => {
//         alert('✅ Attendance submitted! Check console for data.');
//         console.log('📝 Attendance Data:', attendance);
//     };
//     const handleSeeMore = () => {
//         setVisibleCount((prev) => prev + 10);
//     };
//     return (
//         <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4 sm:p-8">
//             <div className="max-w-5xl mx-auto bg-white rounded-xl shadow-xl p-4 sm:p-8">
//                 <h1 className="text-2xl sm:text-3xl font-bold text-center text-blue-700 mb-6">
//                     📋 Smart Attendance System
//                 </h1>
//                 <div className="overflow-x-auto rounded-lg">
//                     <table className="min-w-full text-sm sm:text-base border-separate border-spacing-y-3">
//                         <thead>
//                             <tr>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">#</th>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">Student Name</th>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">Status</th>
//                                 <th className="px-4 py-2 text-gray-600 font-semibold whitespace-nowrap">Action</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             {studentsList.slice(0, visibleCount).map((student, index) => (
//                                 <tr
//                                     key={student.id}
//                                     className="bg-white shadow rounded-xl transition hover:scale-[1.01]"
//                                 >
//                                     <td className="px-4 py-3 text-gray-700 whitespace-nowrap">{index + 1}</td>
//                                     <td className="px-4 py-3 font-medium text-gray-900 whitespace-nowrap">
//                                         {student.name}
//                                     </td>
//                                     <td className="px-4 py-3 whitespace-nowrap">
//                                         {attendance[student.id] ? (
//                                             <span className="inline-flex items-center gap-1 text-green-600 font-semibold">
//                                                 <CheckCircle className="w-4 h-4" /> Present
//                                             </span>
//                                         ) : (
//                                             <span className="inline-flex items-center gap-1 text-red-500 font-semibold">
//                                                 <XCircle className="w-4 h-4" /> Absent
//                                             </span>
//                                         )}
//                                     </td>
//                                     <td className="px-4 py-3 whitespace-nowrap">
//                                         <button
//                                             onClick={() => toggleAttendance(student.id)}
//                                             className={`px-3 py-1 sm:px-4 sm:py-2 rounded-full font-semibold text-white transition-all duration-300 text-sm sm:text-base ${attendance[student.id]
//                                                     ? 'bg-red-500 hover:bg-red-600'
//                                                     : 'bg-green-500 hover:bg-green-600'
//                                                 }`}
//                                         >
//                                             Mark {attendance[student.id] ? 'Absent' : 'Present'}
//                                         </button>
//                                     </td>
//                                 </tr>
//                             ))}
//                         </tbody>
//                     </table>
//                 </div>
//                 {visibleCount < studentsList.length && (
//                     <div className="text-center mt-6">
//                         <button
//                             onClick={handleSeeMore}
//                             className="text-blue-600 font-semibold hover:underline"
//                         >
//                             ↓ See more students
//                         </button>
//                     </div>
//                 )}
//                 <div className="text-center mt-10">
//                     <button
//                         onClick={handleSubmit}
//                         className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-base sm:text-lg font-semibold shadow-md transition-all duration-300"
//                     >
//                         ✅ Submit Attendance
//                     </button>
//                 </div>
//             </div>
//         </div>
//     );
// }
__turbopack_context__.s({
    "default": (()=>AttendancePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-ssr] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-ssr] (ecmascript) <export default as XCircle>");
'use client';
;
;
;
const studentsList = [
    'Aarav Patil',
    'Sneha Deshmukh',
    'Rohan Jadhav',
    'Pooja Shinde',
    'Omkar Pawar',
    'Prachi Kale',
    'Tanmay More',
    'Rutuja Chavan',
    'Sahil Gaikwad',
    'Shruti Joshi',
    'Kunal Salunkhe',
    'Isha Kadam',
    'Pratik Naik',
    'Neha Bhosale',
    'Aniket Lokhande',
    'Vaishnavi Phadke',
    'Aditya Gite',
    'Manasi Thakur',
    'Sanket Raut',
    'Komal Wagh',
    'Nikhil Khot',
    'Sayali Shingade',
    'Tushar Zende',
    'Megha Wavhal',
    'Jay Pingle',
    'Asmita Gawade',
    'Saurabh Bhujbal',
    'Diksha Bane',
    'Shubham Rane',
    'Ketaki Khare'
].map((name, index)=>({
        id: index + 1,
        name
    }));
function AttendancePage() {
    const [attendance, setAttendance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [visibleCount, setVisibleCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(10);
    const toggleAttendance = (id)=>{
        setAttendance((prev)=>({
                ...prev,
                [id]: !prev[id]
            }));
    };
    const handleSubmit = ()=>{
        alert('✅ Attendance submitted! Check console for data.');
        console.log('📝 Attendance Data:', attendance);
    };
    const handleSeeMore = ()=>{
        setVisibleCount((prev)=>prev + 10);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-slate-100 to-slate-300 p-4 sm:p-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-6xl mx-auto bg-white/70 backdrop-blur-xl rounded-3xl shadow-2xl px-6 py-8 sm:p-12 border border-gray-200",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-3xl sm:text-4xl font-bold text-center text-blue-800 mb-10 tracking-tight",
                    children: "📋 Smart Attendance System"
                }, void 0, false, {
                    fileName: "[project]/app/Attendance/page.tsx",
                    lineNumber: 152,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "overflow-x-auto rounded-xl",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "min-w-full border-separate border-spacing-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: "text-left text-gray-600 text-sm sm:text-base",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "px-4 py-2 font-semibold",
                                            children: "#"
                                        }, void 0, false, {
                                            fileName: "[project]/app/Attendance/page.tsx",
                                            lineNumber: 160,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "px-4 py-2 font-semibold",
                                            children: "Student Name"
                                        }, void 0, false, {
                                            fileName: "[project]/app/Attendance/page.tsx",
                                            lineNumber: 161,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "px-4 py-2 font-semibold",
                                            children: "Status"
                                        }, void 0, false, {
                                            fileName: "[project]/app/Attendance/page.tsx",
                                            lineNumber: 162,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "px-4 py-2 font-semibold",
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/app/Attendance/page.tsx",
                                            lineNumber: 163,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/Attendance/page.tsx",
                                    lineNumber: 159,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/Attendance/page.tsx",
                                lineNumber: 158,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: studentsList.slice(0, visibleCount).map((student, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "bg-white/60 shadow-md rounded-xl transition transform hover:scale-[1.01] duration-300",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "px-4 py-3 text-gray-700 font-medium",
                                                children: index + 1
                                            }, void 0, false, {
                                                fileName: "[project]/app/Attendance/page.tsx",
                                                lineNumber: 172,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "px-4 py-3 text-gray-900 font-semibold",
                                                children: student.name
                                            }, void 0, false, {
                                                fileName: "[project]/app/Attendance/page.tsx",
                                                lineNumber: 173,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "px-4 py-3",
                                                children: attendance[student.id] ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "inline-flex items-center gap-1 text-green-600 font-semibold",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                                            className: "w-5 h-5"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/Attendance/page.tsx",
                                                            lineNumber: 177,
                                                            columnNumber: 49
                                                        }, this),
                                                        " Present"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/Attendance/page.tsx",
                                                    lineNumber: 176,
                                                    columnNumber: 45
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "inline-flex items-center gap-1 text-red-500 font-semibold",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"], {
                                                            className: "w-5 h-5"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/Attendance/page.tsx",
                                                            lineNumber: 181,
                                                            columnNumber: 49
                                                        }, this),
                                                        " Absent"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/Attendance/page.tsx",
                                                    lineNumber: 180,
                                                    columnNumber: 45
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/Attendance/page.tsx",
                                                lineNumber: 174,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "px-4 py-3",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>toggleAttendance(student.id),
                                                    className: `px-4 py-2 rounded-full text-white font-semibold text-sm transition-all duration-300 ${attendance[student.id] ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'}`,
                                                    children: [
                                                        "Mark ",
                                                        attendance[student.id] ? 'Absent' : 'Present'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/Attendance/page.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/Attendance/page.tsx",
                                                lineNumber: 185,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, student.id, true, {
                                        fileName: "[project]/app/Attendance/page.tsx",
                                        lineNumber: 168,
                                        columnNumber: 33
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/Attendance/page.tsx",
                                lineNumber: 166,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/Attendance/page.tsx",
                        lineNumber: 157,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/Attendance/page.tsx",
                    lineNumber: 156,
                    columnNumber: 17
                }, this),
                visibleCount < studentsList.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mt-8",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleSeeMore,
                        className: "text-blue-700 font-medium hover:underline tracking-wide",
                        children: "↓ See more students"
                    }, void 0, false, {
                        fileName: "[project]/app/Attendance/page.tsx",
                        lineNumber: 204,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/Attendance/page.tsx",
                    lineNumber: 203,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center mt-10",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleSubmit,
                        className: "w-full sm:w-auto px-8 py-3 bg-blue-700 hover:bg-blue-800 text-white rounded-2xl text-lg font-semibold shadow-md transition duration-300",
                        children: "✅ Submit Attendance"
                    }, void 0, false, {
                        fileName: "[project]/app/Attendance/page.tsx",
                        lineNumber: 214,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/Attendance/page.tsx",
                    lineNumber: 213,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/Attendance/page.tsx",
            lineNumber: 151,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/Attendance/page.tsx",
        lineNumber: 150,
        columnNumber: 9
    }, this);
}
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s({
    "__iconNode": (()=>__iconNode),
    "default": (()=>CircleCheckBig)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M21.801 10A10 10 0 1 1 17 3.335",
            key: "yps3ct"
        }
    ],
    [
        "path",
        {
            d: "m9 11 3 3L22 4",
            key: "1pflzl"
        }
    ]
];
const CircleCheckBig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("circle-check-big", __iconNode);
;
 //# sourceMappingURL=circle-check-big.js.map
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-ssr] (ecmascript) <export default as CheckCircle>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CheckCircle": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-ssr] (ecmascript)");
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s({
    "__iconNode": (()=>__iconNode),
    "default": (()=>CircleX)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "m15 9-6 6",
            key: "1uzhvr"
        }
    ],
    [
        "path",
        {
            d: "m9 9 6 6",
            key: "z0biqf"
        }
    ]
];
const CircleX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("circle-x", __iconNode);
;
 //# sourceMappingURL=circle-x.js.map
}}),
"[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-ssr] (ecmascript) <export default as XCircle>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "XCircle": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.js [app-ssr] (ecmascript)");
}}),

};

//# sourceMappingURL=_39fb6cee._.js.map